-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: yanolja
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `createdate` timestamp NOT NULL,
  `modifydate` timestamp NULL DEFAULT NULL,
  `phone` int NOT NULL,
  `masteryn` tinyint(1) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'척준경','$2a$10$HuOOIpl/T14hpj9T/QgBWeUVm8qfEydx4jGx5YxC8LkbKZHDEh4pi','chuck@jun','2023-08-16 14:52:23',NULL,1234,0),(2,'김순호','$2a$10$3scHFkP5nQJMP1Ul9xepZ.DkaoKUyjv7T1wzSN6g7vw1KgmgJeH5m','kim@sun.ho','2023-08-21 22:56:31',NULL,1111,0),(3,'제임스','$2a$10$tDarEw3k3dh3sKvan1WRce87B7JqGiUbe8sKKl9UukmIYhxDsShy.','1@1','2023-08-29 20:43:50',NULL,1011111111,0),(4,'권','$2a$10$n0tANZXvLI69p67mXNpP2eCPOzTE0OQQidfiiMXJ4c.NT59qXLlQi','123@1231','2023-08-31 20:11:34',NULL,123451234,0),(5,'전라도 통 14','$2a$10$2fc7iYxa0n0fohduEvDOC.yt.jRK6kuGe5ZSN3GnHfdJiu00yO1i2','zodls1128@gmail.com','2023-09-06 15:33:53',NULL,1025023964,0),(6,'서울 물주먹 17','$2a$10$q7E21wuiY4/fzVBqxJOUZ.yaEOoG7EudTVy62NA1AcRwJxWow2jNW','kosq1234@naver.com','2023-09-07 15:15:49',NULL,1012345678,0),(7,'경상도 통 7','$2a$10$cx7Qd3AxY7CWHC9gOxEVPeLYLM.gvqokQAW54fpnePMbmx1tWmkkS','kosq3964@naver.com','2023-10-05 19:02:45',NULL,1012345678,0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-27 10:22:17
